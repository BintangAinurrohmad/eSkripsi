<section class="section">
	<div class="card">
		<div class="card-body">

			<embed class="mt-3" src="<?php echo base_url('file/proposal/naskah/' . $file_naskah); ?>" type="application/pdf" width="100%" height="600px" />

		</div>
	</div>
</section>
