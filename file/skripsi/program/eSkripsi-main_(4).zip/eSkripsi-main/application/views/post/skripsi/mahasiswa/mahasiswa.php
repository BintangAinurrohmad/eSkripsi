
<section class="section">
        <div class="card">
            <div class="card-body">
              <form>

                <div class="row mb-3 mt-3">
                  <label class="col-sm-2 col-form-label">Judul</label>
                  <div class="col-sm-10 mt-2">
                  Rancang Bangun Sistem Informasi Skripsi Menggunakan Metode FAST
                  </div>
                </div>

                <div class="row mb-3 mt-3">
                  <label class="col-sm-2 col-form-label">Naskah Proposal</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" placeholder="Pilih File">
                  </div>
                </div>

                <div class="row mb-3 mt-3">
                  <label class="col-sm-2 col-form-label">Program</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" placeholder="Pilih File">
                  </div>
                </div>

                  <div class="col-sm-10" align="center">
                    <button type="submit" class="btn btn-primary">Kirim</button>
                  </div>

              </form>
            </div>
        </div>
</section>
