<section class="section">
	<div class="card">
		<div class="card-body">

					<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
						Anda belum lulus ujian skripsi
					</div>

		</div>
	</div>
</section>
