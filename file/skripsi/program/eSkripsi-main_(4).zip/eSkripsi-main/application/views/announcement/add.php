<section class="section">
	<div class="card">
		<div class="card-body">
			<h5 class="card-title"></h5>

			<!-- Floating Labels Form -->
			<form class="row g-3">

				<div class="col-md-12">
					<div class="form-floating">
						<input type="text" class="form-control" id="floatingName" placeholder="Your Name">
						<label for="floatingName">Your Name</label>
					</div>
				</div>

				<div class="quill-editor-default mt-3">
				</div>

				<div class="text-center">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>

		</div>
	</div>
</section>
